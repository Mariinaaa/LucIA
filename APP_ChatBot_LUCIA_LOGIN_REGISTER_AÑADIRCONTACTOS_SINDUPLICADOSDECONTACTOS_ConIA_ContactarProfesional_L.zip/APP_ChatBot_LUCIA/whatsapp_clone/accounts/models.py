from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.utils import timezone

class CustomUserManager(BaseUserManager):
    def create_user(self, phone_number, password=None, **extra_fields):
        if not phone_number:
            raise ValueError("El número de teléfono es obligatorio")
        user = self.model(phone_number=phone_number, **extra_fields)
        user.set_password(password)  # Password hasheada
        user.save(using=self._db)
        return user

    def create_superuser(self, phone_number, password, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(phone_number, password, **extra_fields)

class CustomUser(AbstractBaseUser, PermissionsMixin):
    phone_number = models.CharField(max_length=20, unique=True)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    date_joined = models.DateTimeField(default=timezone.now)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    USERNAME_FIELD = 'phone_number'
    REQUIRED_FIELDS = ['first_name', 'last_name']

    objects = CustomUserManager()

    def __str__(self):
        return self.phone_number
    
    
from django.db import models

from django.conf import settings


class Contact(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='contacts')
    name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=20)
    country = models.CharField(max_length=2, default='ES')

    class Meta:
        unique_together = ('user', 'phone_number')  # ❗️Evita duplicados para un mismo usuario

    def __str__(self):
        return f"{self.name} ({self.phone_number})"



#------------------------------Persistencia de mensajes---Al enviar/recibir un mensaje, guarda en la base de datos.--------------------------
from django.db import models
from django.conf import settings
class Message(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    contact = models.CharField(max_length=255)
    sender = models.CharField(max_length=10, choices=[('user', 'Usuario'), ('bot', 'LucIA')])
    text = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)



