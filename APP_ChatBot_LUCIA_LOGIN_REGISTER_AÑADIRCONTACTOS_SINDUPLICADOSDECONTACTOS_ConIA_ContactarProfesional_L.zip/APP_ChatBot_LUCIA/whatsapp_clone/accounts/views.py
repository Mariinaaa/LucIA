import os
import json
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from dotenv import load_dotenv
import google.generativeai as genai

from django.shortcuts import render, redirect
from django.contrib.auth import login
from .forms import RegisterForm



# Cargar .env manualmente desde la raíz del proyecto
dotenv_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
load_dotenv(dotenv_path)

# Configurar clave directamente (fallback si .env falla)
genai.configure(api_key=os.getenv("GOOGLE_API_KEY") or "AIzaSyALx4u2SfnyLThWAxYwDQAPfPE9JsMR9Kg")

# Modelo válido
model = genai.GenerativeModel("models/gemini-1.5-flash")
"""models = genai.list_models()
for m in models:
    print(m.name)"""

@csrf_exempt
def chatbot_response(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            message = data.get("message", "")

            if not message:
                return JsonResponse({"response": "No se recibió mensaje."})

            palabras_alerta_alta = [
                "me quiero morir", "no quiero vivir", "me pegan", "me gritan mucho", 
                "me insulta", "siento que no valgo nada"
            ]
            palabras_alerta_media = [
                "me siento sola", "duermo mal", "me controla", 
                "me vigila", "estoy muy cansada", "tengo miedo"
            ]

            alert_level = "none"
            for palabra in palabras_alerta_alta:
                if palabra in message.lower():
                    alert_level = "alto"
                    break
            else:
                for palabra in palabras_alerta_media:
                    if palabra in message.lower():
                        alert_level = "medio"
                        break

            prompt = (
                "Eres LucIA, una inteligencia artificial empática y sensible, especializada en bienestar emocional "
                "y detección de señales de riesgo como violencia doméstica, pensamientos depresivos o cambios de comportamiento. "
                "No haces diagnósticos médicos, pero das apoyo emocional.\n\n"
                f"Mensaje del usuario: {message}\n\n"
                "Responde con empatía y ofrece contención. Si detectas riesgo, sugiere contactar a familiares, psicólogos o emergencias (112)."
            )

            response = model.generate_content(prompt)

            return JsonResponse({
                "response": response.text,
                "alert_level": alert_level
            })

        except Exception as e:
            return JsonResponse({
                "response": f"❌ Error: {str(e)}",
                "alert_level": "error"
            })
            
from .models import Message  # asegúrate de tener esto arriba del archivo

from django.contrib.auth.decorators import login_required
from django.utils.decorators import decorator_from_middleware
from django.views.decorators.csrf import csrf_exempt


@csrf_exempt
@login_required
def chatbot_response(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            message = data.get("message", "")
            if not message:
                return JsonResponse({"response": "No se recibió mensaje."})

            mensaje_normalizado = message.lower()

            # 🧭 Detectar si el mensaje anterior de LucIA pedía ubicación
            solicita_ubicacion = any(frase in mensaje_normalizado for frase in [
                "enviarme tu ubicación", "puedes enviarme tu ubicación",
                "compartir tu ubicación", "mandar tu ubicación", "tu ubicación actual"
            ])

            # Palabras clave de alerta
            palabras_alerta_alta = [ # VIOLENCIA
                "me quiero morir", "no quiero vivir", "me pegan", "me gritan mucho", 
                "me insulta", "siento que no valgo nada", "me hace daño"
            ]
            palabras_alerta_media = [ # EMOCIONES
                "me siento sola", "duermo mal", "me controla", "me vigila", 
                "estoy muy cansada", "tengo miedo", "me siento vigilada"
            ]
            palabras_personas_mayores = [ # MÉDICO
                "me olvido de todo", "me caí", "tengo dolor", "estoy cansado", 
                "pierdo el equilibrio", "no recuerdo bien", "me siento confundido"
            ]

            alert_level = "none"
            alert_message = ""
            show_professional_button = False
            professional_type = "emocional"

            if any(p in mensaje_normalizado for p in palabras_alerta_alta):
                alert_level = "alto"
                alert_message = (
                    "🚨 Detectamos señales de posible violencia o sufrimiento severo. "
                    "Por favor, considera hablar con alguien de confianza, un profesional o llamar al 112."
                )
                show_professional_button = True
                professional_type = "violencia"
            elif any(p in mensaje_normalizado for p in palabras_alerta_media):
                alert_level = "medio"
                alert_message = (
                    "⚠️ LucIA detectó algunas señales de malestar emocional. "
                    "No estás sola/o, puedes pedir ayuda y hablar con alguien cercano."
                )
                show_professional_button = True
                professional_type = "emocional"
            elif any(p in mensaje_normalizado for p in palabras_personas_mayores):
                alert_level = "personas_mayores"
                alert_message = (
                    "👵 LucIA notó posibles señales de deterioro cognitivo o físico. "
                    "Es recomendable una visita al médico o avisar a un familiar para seguimiento."
                )
                show_professional_button = True
                professional_type = "medico"

            # Generar respuesta con Gemini
            prompt = (
                "Eres LucIA, una inteligencia artificial empática. Ayudas a personas mayores y detectas posibles casos de violencia o problemas emocionales.\n\n"
                f"Mensaje del usuario: {message}\n\n"
                "Responde con sensibilidad, valida las emociones y, si es necesario, sugiere contactar a profesionales o servicios de ayuda. "
                "Si crees que sería útil, pide al usuario su ubicación actual."
            )

            response = model.generate_content(prompt)

            # Guardar mensajes
            user = request.user
            if user:
                from .models import Message
                Message.objects.create(user=user, contact="LucIA", sender="user", text=message)
                Message.objects.create(user=user, contact="LucIA", sender="bot", text=response.text)

            # Detectar si LucIA solicita ubicación
            if any(p in response.text.lower() for p in [
                "envíame tu ubicación", "puedes enviarme tu ubicación", 
                "comparte tu ubicación", "compartir tu ubicación"
            ]):
                solicita_ubicacion = True

            return JsonResponse({
                "response": f"{response.text}\n\n{alert_message if alert_level != 'none' else ''}",
                "alert_level": alert_level,
                "show_professional_button": show_professional_button,
                "professional_type": professional_type,
                "solicita_ubicacion": solicita_ubicacion
            })

        except Exception as e:
            return JsonResponse({
                "response": f"❌ Error: {str(e)}",
                "alert_level": "error",
                "show_professional_button": False,
                "solicita_ubicacion": False
            })





from django.contrib.auth import authenticate, login
from .forms import LoginForm



from django.shortcuts import render, redirect
"""
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = authenticate(
                request,
                username=form.cleaned_data.get('username'),
                password=form.cleaned_data.get('password')
            )
            if user:
                login(request, user)
                return redirect('chatbot', name=user.first_name)
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})
"""
import random
import time
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from .forms import LoginForm
from django.contrib.auth import get_user_model

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            phone = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=phone, password=password)

            if user:
                # ✅ Generar OTP de 6 dígitos
                otp_code = f"{random.randint(100000, 999999)}"
                request.session['otp_user_id'] = user.id
                request.session['otp_code'] = otp_code
                request.session['otp_time'] = int(time.time())

                print(f"[SIMULADO] Código enviado por SMS a {phone}: {otp_code}")  # Dev mode

                return redirect('verificar_otp')  # 👈 Redirige a nueva vista

            else:
                messages.error(request, "Credenciales inválidas.")
    else:
        form = LoginForm()

    return render(request, 'login.html', {'form': form})
from django.contrib.auth import get_user_model
from django.utils import timezone

def verificar_otp_view(request):
    if request.method == 'POST':
        code = request.POST.get('otp_code')
        otp_code = request.session.get('otp_code')
        otp_time = request.session.get('otp_time')
        user_id = request.session.get('otp_user_id')

        # Verificamos tiempo (5 minutos = 300 segundos)
        if otp_time and int(time.time()) - otp_time > 300:
            messages.error(request, "El código ha expirado.")
            return redirect('login')

        if code == otp_code and user_id:
            user = get_user_model().objects.get(id=user_id)
            login(request, user)

            # 🧼 Limpieza
            request.session.pop('otp_code', None)
            request.session.pop('otp_time', None)
            request.session.pop('otp_user_id', None)

            return redirect('chatbot', name=user.first_name)
        else:
            messages.error(request, "Código incorrecto.")

    return render(request, 'verificar_otp.html')






def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)
            return redirect('login')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

from .models import Contact
from django.contrib.auth.decorators import login_required

@login_required
def chatbot_view(request, name):
    if request.method == 'POST':
        contact_name = request.POST.get('contact_name')
        if contact_name:
            Contact.objects.create(user=request.user, name=contact_name)

    contacts = Contact.objects.filter(user=request.user)

    # 👇 Añadir esto para mostrar historial con LucIA
    messages = Message.objects.filter(user=request.user, contact="LucIA").order_by("timestamp")

    return render(request, 'chatbot.html', {
        'name': name,
        'contacts': contacts,
        'messages': messages  # 👈 pasamos mensajes al template
    })

from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .models import Contact
import json

@login_required
@csrf_exempt
def add_contact_view(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            name = data.get('name')
            phone = data.get('phone')
            country = data.get('country')

            if not all([name, phone, country]):
                return JsonResponse({'status': 'error', 'message': 'Datos incompletos'})

            # ⚠️ Verificar si el número ya existe para este usuario
            if Contact.objects.filter(user=request.user, phone_number=phone).exists():
                return JsonResponse({'status': 'error', 'message': 'Este número ya está registrado'})

            # ✅ Crear nuevo contacto
            Contact.objects.create(
                user=request.user,
                name=name,
                phone_number=phone,
                country=country
            )

            return JsonResponse({'status': 'ok'})

        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)

    return JsonResponse({'status': 'error', 'message': 'Método no permitido'}, status=405)


from django.contrib.auth import logout
from django.views.decorators.cache import never_cache

@never_cache
def logout_view(request):
    request.session.flush()  # 🧹 Borra toda la sesión (incluye CSRF token viejo)
    logout(request)          # 👤 Cierra la sesión del usuario
    return redirect('login')  # 🔁 Redirige al login con sesión limpia




from django.contrib.auth.decorators import login_required
@login_required
def professional_chat_view(request, type):
    # Puedes usar esta lógica para renderizar diferentes tipos de profesionales
    if type == "emocional":
        nombre = "Psicóloga Clara"
    elif type == "violencia":
        nombre = "Asesora Legal Marta"
    elif type == "medico":
        nombre = "Doctor Javier"
    else:
        nombre = "Profesional"

    return render(request, 'professional_chat.html', {'nombre': nombre})

from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from .models import Contact


from django.contrib.auth.decorators import login_required
from django.shortcuts import render


    
@login_required
def professional_chat_view(request, type):
    contacts = Contact.objects.filter(user=request.user)
    return render(request, 'chatbot_integrado.html', {
        'contacts': contacts,
        'professional_type': type
    })


from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required

@csrf_exempt
@login_required
def delete_contact_view(request):
    if request.method == "POST":
        data = json.loads(request.body)
        phone = data.get("phone")

        try:
            # LucIA no se elimina
            if phone == "AI-BOT":
                return JsonResponse({"status": "error", "message": "LucIA no se puede eliminar"})

            contacto = Contact.objects.get(user=request.user, phone_number=phone)
            contacto.delete()
            return JsonResponse({"status": "ok"})
        except Contact.DoesNotExist:
            return JsonResponse({"status": "error", "message": "Contacto no encontrado"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

    return JsonResponse({"status": "error", "message": "Método no permitido"}, status=405)



#PERFIL
from django.contrib.auth.decorators import login_required
@login_required
def user_profile_view(request):
    user = request.user
    return render(request, 'user_profile.html', {
        'name': user.first_name,
        'phone': user.phone_number
    })




#verificacion en dos pasos
