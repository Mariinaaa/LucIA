from django.urls import path
from . import views
from .views import chatbot_view
from .views import add_contact_view
from accounts.views import logout_view
from .views import chatbot_response
from .views import logout_view
from .views import professional_chat_view
from django.urls import path
from .views import delete_contact_view
from .views import user_profile_view
from .views import verificar_otp_view



urlpatterns = [
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('chatbot/<str:name>/', chatbot_view, name='chatbot'),  
    path('add_contact/', add_contact_view, name='add_contact'),  
    path('logout/', logout_view, name='logout'),
    path('logout/', views.logout_view, name='logout'),
    path("chatbot-response/", chatbot_response, name="chatbot_response"),
    path('add_contact/', add_contact_view, name='add_contact'),
    path('logout/', logout_view, name='logout'),
    path('chatbot-profesional/<str:type>/', views.professional_chat_view, name='professional_chat'),
    path("delete-contact/", delete_contact_view, name="delete_contact"),
    path('perfil/', user_profile_view, name='user_profile'),
# en urls.py
    path('verificar-otp/', verificar_otp_view, name='verificar_otp'),


]