from pathlib import Path
import os
#OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

import os
from pathlib import Path

# Definir BASE_DIR correctamente
BASE_DIR = Path(__file__).resolve().parent.parent

STATIC_URL = '/static/'

STATICFILES_DIRS = [
    os.path.join(BASE_DIR, "static"),
]



# Configurar clave API de OpenAI manualmente si no se carga desde las variables de entorno
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "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")

# Verificar que la clave se cargó correctamente
print(f"🔑 OpenAI API Key cargada: {OPENAI_API_KEY}")




# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# Quick-start development settings - unsuitable for production
DEBUG = True

ALLOWED_HOSTS = ["*"]  # Permitir todas las conexiones en desarrollo

# Application definition
INSTALLED_APPS = [
    'daphne',  # Soporte para WebSockets
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'chat',  # Nuestra aplicación de chat
    'channels',  # Habilitar Django Channels
]
AUTH_USER_MODEL = 'chat.CustomUser'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / "templates"],  # Agregar si tienes una carpeta global
        'APP_DIRS': True,  # Buscar templates en apps instaladas
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]


# Middleware
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]
SECRET_KEY = ''
SECRET_KEY = 'aBcdEfGhIjKlMnOpQrStUvWxYz1234567890ABCDEFGHIJKL'

# Enrutamiento ASGI para WebSockets
ROOT_URLCONF = 'RealTimeChat.urls'
ASGI_APPLICATION = "RealTimeChat.asgi.application"  # 👈 Importante para WebSockets



WSGI_APPLICATION = 'RealTimeChat.wsgi.application'

# Configuración de la base de datos
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Configurar capas de canales para WebSockets
CHANNEL_LAYERS = {
    "default": {
        "BACKEND": "channels.layers.InMemoryChannelLayer",  # Usar InMemory en desarrollo
    },
}

# Configuración de autenticación
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# Configuración de idioma y zona horaria
LANGUAGE_CODE = 'es'
TIME_ZONE = 'Europe/Madrid'  # O ajusta a tu zona horaria

USE_I18N = True
USE_TZ = True

# Configuración de archivos estáticos
STATIC_URL = 'static/'
STATICFILES_DIRS = [BASE_DIR / "static"]  # Opcional, si tienes archivos estáticos globales

# Definir clave primaria por defecto
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

