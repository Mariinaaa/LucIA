from django.contrib import admin  # 👈 Importar admin correctamente
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),  # 👈 Debe estar bien escrito
    path('', include('chat.urls')),   # Agregar rutas de tu app
]
