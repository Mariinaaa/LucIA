from django.urls import path
from .views import home, register_view, login_view, logout_view, chat_view, add_contact, chatbot_response  # ✅ IMPORTANTE

urlpatterns = [
    path("", home, name="home"),
    path("register/", register_view, name="register"),
    path("login/", login_view, name="login"),
    path("logout/", logout_view, name="logout"),
    path("chat/", chat_view, name="chat"),
    path("add_contact/", add_contact, name="add_contact"),
    path("chatbot-response/", chatbot_response, name="chatbot_response"),  # ✅ Nueva API de LucIA
]
