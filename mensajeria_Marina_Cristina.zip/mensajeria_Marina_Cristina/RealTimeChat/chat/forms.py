from django import forms
from chat.models import CustomUser
from django.contrib.auth.hashers import check_password
import re  


class RegisterForm(forms.ModelForm):
    phone_number = forms.CharField(
        max_length=13,
        widget=forms.TextInput(attrs={'placeholder': '+34 123 456 789'}),
        required=True
    )
    password = forms.CharField(widget=forms.PasswordInput, min_length=6)

    class Meta:
        model = CustomUser
        fields = ['phone_number', 'first_name', 'last_name', 'password']

    def clean_phone_number(self):
        phone_number = self.cleaned_data['phone_number']

        # Asegurar que comience con +34
        if not phone_number.startswith("+34"):
            phone_number = "+34" + phone_number

        # Eliminar cualquier carácter no numérico excepto el prefijo "+34"
        phone_number = re.sub(r'[^\d]', '', phone_number)  # Quita cualquier carácter no numérico
        phone_number = "+34" + phone_number[-9:]  # Asegurar que tenga solo los últimos 9 dígitos

        if len(phone_number) != 12:  # +34 y 9 números = 12 caracteres
            raise forms.ValidationError("El número debe tener exactamente 9 dígitos después de +34.")

        return phone_number

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()
        return user


class LoginForm(forms.Form):
    phone_number = forms.CharField(max_length=13, widget=forms.TextInput(attrs={'placeholder': '+34'}))
    password = forms.CharField(widget=forms.PasswordInput)

    def clean_phone_number(self):
        phone_number = self.cleaned_data['phone_number']

        # Asegurar que comience con +34
        if not phone_number.startswith("+34"):
            phone_number = "+34" + phone_number

        # Eliminar cualquier carácter no numérico excepto el prefijo "+34"
        phone_number = re.sub(r'[^\d]', '', phone_number)  # Quita cualquier carácter no numérico
        phone_number = "+34" + phone_number[-9:]  # Asegurar que tenga solo los últimos 9 dígitos

        if len(phone_number) != 12:
            raise forms.ValidationError("El número debe tener exactamente 9 dígitos después de +34.")

        return phone_number

    def clean(self):
        phone_number = self.cleaned_data.get("phone_number")
        password = self.cleaned_data.get("password")

        try:
            user = CustomUser.objects.get(phone_number=phone_number)
        except CustomUser.DoesNotExist:
            raise forms.ValidationError("Número de teléfono no registrado.")

        if not user.check_password(password):
            raise forms.ValidationError("Contraseña incorrecta.")

        return self.cleaned_data
