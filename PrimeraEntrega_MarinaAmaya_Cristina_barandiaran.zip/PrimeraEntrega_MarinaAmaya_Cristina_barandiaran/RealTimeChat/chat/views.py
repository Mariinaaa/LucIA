import json
import os
from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from chat.models import CustomUser
from .forms import RegisterForm, LoginForm
import google.generativeai as genai

#  Cargar la clave de API desde las variables de entorno
genai_api_key = os.getenv("GOOGLE_GEMINI_API_KEY")

if not genai_api_key:
    raise ValueError("⚠️ ERROR: No se encontró la clave API de Google Gemini. Asegúrate de configurarla correctamente.")

genai.configure(api_key=genai_api_key)

#  Modelo de Google Gemini (puedes cambiarlo si da error)
MODEL_NAME = "gemini-1.5-flash-latest"

#  API del Chatbot LucIA con Google Gemini AI
@login_required
@csrf_exempt
def chatbot_response(request):
    """API para responder mensajes con Google Gemini AI en español."""
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            user_message = data.get("message", "").strip()

            if not user_message:
                return JsonResponse({"error": "Mensaje vacío"}, status=400)

            # Diccionario de respuestas rápidas en español
            predefined_responses = {
                "hola": "¡Hola! Soy LucIA, tu asistente virtual. ¿En qué puedo ayudarte? 😊",
                "cómo estás": "Estoy aquí para ayudarte. ¿Tienes alguna duda? 😊",
                "qué puedes hacer": "Puedo responder preguntas, ayudarte a navegar en la app y más.",
                "adiós": "¡Hasta pronto! 😊",
                "gracias": "De nada, estoy aquí para ayudarte. 🙌",
            }

            #  Si hay una respuesta predefinida, usarla
            if user_message.lower() in predefined_responses:
                response_text = predefined_responses[user_message.lower()]
            else:
                #  Llamada a Google Gemini AI para responder en español
                model = genai.GenerativeModel(MODEL_NAME)
                prompt = f"Eres LucIA, un asistente virtual amable que responde en español. Responde de manera breve y natural a lo siguiente:\nUsuario: {user_message}\nLucIA:"
                
                try:
                    response = model.generate_content(prompt)
                    response_text = getattr(response, "text", "Lo siento, no entendí la pregunta.")
                except Exception as ai_error:
                    if "429" in str(ai_error):
                        response_text = "Lo siento, he alcanzado el límite de consultas por ahora. Inténtalo más tarde."
                    else:
                        response_text = f"Error al procesar la solicitud con Google AI: {str(ai_error)}"

            return JsonResponse({"response": response_text})

        except json.JSONDecodeError:
            return JsonResponse({"error": "Formato JSON inválido"}, status=400)
        except Exception as e:
            return JsonResponse({"error": f"Error inesperado: {str(e)}"}, status=500)

    return JsonResponse({"error": "Método no permitido"}, status=405)

#  Vista de inicio
def home(request):
    return render(request, "chat/home.html")

#  Registro de usuario
def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("login")
    else:
        form = RegisterForm()
    return render(request, "chat/register.html", {"form": form})

#  Inicio de sesión
def login_view(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            phone_number = form.cleaned_data["phone_number"]
            try:
                user = CustomUser.objects.get(phone_number=phone_number)
                login(request, user)
                return redirect("chat")
            except CustomUser.DoesNotExist:
                return JsonResponse({"status": "error", "message": "Número no registrado."}, status=400)
    else:
        form = LoginForm()
    return render(request, "chat/login.html", {"form": form})

#  Cerrar sesión
def logout_view(request):
    logout(request)
    return redirect("home")

#  Vista del chat con contactos y LucIA
@login_required
def chat_view(request):
    contacts = CustomUser.objects.exclude(phone_number=request.user.phone_number)

    chatbot = {
        "phone_number": "AI-BOT",
        "first_name": "Chatbot",
        "last_name": "LucIA",
    }

    return render(request, "chat/chat.html", {"contacts": contacts, "chatbot": chatbot})

#  Añadir un contacto
@login_required
def add_contact(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            name = data.get("name")
            phone = data.get("phone")

            if not name or not phone:
                return JsonResponse({"status": "error", "message": "Nombre y teléfono requeridos."})

            if CustomUser.objects.filter(phone_number=phone).exists():
                return JsonResponse({"status": "error", "message": "El número ya está registrado."})

            CustomUser.objects.create(phone_number=phone, first_name=name)
            return JsonResponse({"status": "ok", "message": "Contacto agregado correctamente."})

        except json.JSONDecodeError:
            return JsonResponse({"status": "error", "message": "Formato JSON inválido."})

    return JsonResponse({"status": "error", "message": "Método no permitido"}, status=405)
